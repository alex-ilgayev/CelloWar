package com.alar.cellowar.shared.datatypes;

/**
 * Created by Alex on 4/11/2015.
 */
public enum ConnectionStatus {
    CONNECTION_NOT_TRIED_YET,
    CONNECTION_OK,
    CONNECTION_RETRYING,
    CONNECTION_TIMED_OUT,
}
